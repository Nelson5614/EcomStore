<?php

namespace App\Http\Controllers\User;

use App\Helpers\Cart;
use App\Http\Controllers\Controller;
use App\Http\Resources\CartResource;
use App\Models\CartItem;
use App\Models\Product;
use App\Models\UserAddress;
use Illuminate\Http\Request;
use Inertia\Inertia;

class CartController extends Controller
{
    public function view(Request $request)
    {

        $user = $request->user();
        $cartData = Cart::getProductsAndCartItems();
        $products = $cartData[0];
        $cartItemsData = $cartData[1];
        $userAddress = null;
        
        if ($user) {
            $userAddress = UserAddress::where('user_id', $user->id)->latest()->first();
        }
        
        if (count($cartItemsData) > 0) {
            // Merge products with cart items data
            $cartItems = [];
            foreach ($products as $product) {
                if (isset($cartItemsData[$product->id])) {
                    $cartItems[] = [
                        'id' => $cartItemsData[$product->id]['id'] ?? null,
                        'user_id' => $cartItemsData[$product->id]['user_id'] ?? null,
                        'product_id' => $product->id,
                        'quantity' => $cartItemsData[$product->id]['quantity'],
                        'price' => $cartItemsData[$product->id]['price'] ?? $product->price,
                        'product' => $product
                    ];
                }
            }
            
            return Inertia::render(
                'User/CartList',
                [
                    'cartItems' => $cartItems,
                    'userAddress' => $userAddress
                ]
            );
        } else {
            return redirect()->route('home')->with('info', 'your cart is empty');
        }
    }
    public function store(Request $request, Product $product)
    {
        $quantity = $request->post('quantity', 1);
        $user = $request->user();

        if ($user) {
            $cartItem = CartItem::where(['user_id' => $user->id, 'product_id' => $product->id])->first();
            if ($cartItem) {
                $cartItem->increment('quantity');
            } else {
                CartItem::create([
                    'user_id' => $user->id,
                    'product_id' => $product->id,
                    'quantity' => 1,
                ]);
            }
        } else {
            $cartItems = Cart::getCookieCartItems();
            $isProductExists = false;
            foreach ($cartItems as $item) {
                if ($item['product_id'] === $product->id) {
                    $item['quantity'] += $quantity;
                    $isProductExists = true;
                    break;
                }
            }

            if (!$isProductExists) {
                $cartItems[] = [
                    'user_id' => null,
                    'product_id' => $product->id,
                    'quantity' => $quantity,
                    'price' => $product->price,
                ];
            }
            Cart::setCookieCartItems($cartItems);
        }

        return redirect()->back()->with('success', 'cart added successfully');
    }
    public function update(Request $request, Product $product)
    {
        $quantity = $request->integer('quantity');
        $user = $request->user();
        if ($user) {
            CartItem::where(['user_id' => $user->id, 'product_id' => $product->id])->update(['quantity' => $quantity]);
        } else {
            $cartItems = Cart::getCookieCartItems();
            foreach ($cartItems as &$item) {
                if ($item['product_id'] === $product->id) {
                    $item['quantity'] = $quantity;
                    break;
                }
            }
            Cart::setCookieCartItems($cartItems);
        }

        return redirect()->back();
    }
    public function destroy(Request $request, Product $product)
    {
        $user = $request->user();
        if ($user) {
            CartItem::query()->where(['user_id' => $user->id, 'product_id' => $product->id])->first()?->delete();
            if (CartItem::where('user_id', $user->id)->count() <= 0) {
                return redirect()->route('home')->with('info', 'your cart is empty');
            } else {
                return redirect()->back()->with('success', 'item removed successfully');
            }
        } else {
            $cartItems = Cart::getCookieCartItems();
            foreach ($cartItems as $i => &$item) {
                if ($item['product_id'] === $product->id) {
                    array_splice($cartItems, $i, 1);
                    break;
                }
            }
            Cart::setCookieCartItems($cartItems);
            if (count($cartItems) <= 0) {
                return redirect()->route('home')->with('info', 'your cart is empty');
            } else {
                return redirect()->back()->with('success', 'item removed successfully');
            }
        }
    }
}
